/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package private_1;

/**
 *
 * @author lk
 */
public class Private_1 {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        
           
    Konto meinKonto = new Konto();
    meinKonto.setKontonummer(23223);
    meinKonto.setSaldo(400.);
    meinKonto.zahleEin(100000.);
    double saldo = meinKonto.getSaldo();
    System.out.println("Saldo:" + saldo);
        }
    }
    

