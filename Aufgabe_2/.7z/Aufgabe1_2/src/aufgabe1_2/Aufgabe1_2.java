/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aufgabe1_2;

/**
 *
 * @author lk
 */
public class Aufgabe1_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int result;
        for(int i = 1; i < 21; i++){
            result = i*i;
        System.out.println(+i+":\t"+result+"");
        }
    }
    
}
